title: CTFd折腾(1)
date: 2019-12-21 16:56:09
tags:
categories: 技术
---
# 部署CTFd

	这里选择的是阿里云的轻量服务器，主要是云翼计划10块一个月。
    
<!--more-->
    
## 安装环境
	
	ubantu 16.04
    
## 安装过程
	
	这里坑其实不多，正常装一般没问题

1.换源

	百度一搜一大把，这里就不写了
    换完了记得升级一下源
	
    sudo apt-get update
    
2.安装python3

	apt-get install python3
    
3.安装pip

    sudo apt install python-pip
    sudo python3 -m pip install --upgrade pip
    
4.安装git
	
    sudo apt install git
    
5.安装Flask
	
    sudo pip install Flask
    
6.克隆CTFd

	sudo git clone https://github.com/isislab/CTFd.git
    
7.安装CTFd
	
    cd CTFd
	sudo ./prepare.sh

8.运行CTFd

	sudo python serve.py
    
此时应该会有如下代码
	 * Loaded module, <module 'CTFd.plugins.challenges' from '/root/CTFd/CTFd/plugins/challenges/__init__.py'>
     * Loaded module, <module 'CTFd.plugins.dynamic_challenges' from '/root/CTFd/CTFd/plugins/dynamic_challenges/__init__.py'>
     * Loaded module, <module 'CTFd.plugins.flags' from '/root/CTFd/CTFd/plugins/flags/__init__.py'>
     * Serving Flask app "CTFd" (lazy loading)
     * Environment: development
     * Debug mode: on
     * Running on http://127.0.0.1:4000/ (Press CTRL+C to quit)
     * Restarting with stat
     * Loaded module, <module 'CTFd.plugins.challenges' from '/root/CTFd/CTFd/plugins/challenges/__init__.py'>
     * Loaded module, <module 'CTFd.plugins.dynamic_challenges' from '/root/CTFd/CTFd/plugins/dynamic_challenges/__init__.py'>
     * Loaded module, <module 'CTFd.plugins.flags' from '/root/CTFd/CTFd/plugins/flags/__init__.py'>
     * Debugger is active!
     * Debugger PIN: 123-456-789

同时访问localhost:4000就能进入界面了。
如果没有UI界面，新开了一个ssh，Curl访问了一下，看是否有拒绝。
正常这些都没有什么问题，然后就是部署到公网了。


## 部署公网

1.安装gunicorn
	
    sudo pip install gunicorn

2.端口映射

	gunicorn --bind 0.0.0.0:80 -w 10 "CTFd:create_app()"
	#在这里bind直接绑定端口80，默认是4000，也就不需要再修改阿里云的防火墙配置，安全组的配置等。
    #w的参数含义是开启多少个线程，先往多里开再说。
![](https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/%E9%83%A8%E7%BD%B2CTFd/%E6%88%90%E5%8A%9F%E7%99%BB%E5%BD%95.jpg?x-oss-process=style/ki9mu)


## 优化

虽然能够成功登录，但是页面会很卡。

### nginx转发

1.安装nginx
	
    sudo apt-get install nginx

2.更改配置文件
	
    vim /etc/nginx/nginx.conf
    #然后新增一些代码
     server{
                listen 80;
                server_name  你的ip;
                location / {
                        proxy_pass http://127.0.0.1:4000;
                        proxy_set_header Host $http_host;
                        proxy_set_header X-Real-IP $remote_addr;
                        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                        proxy_redirect off;
                }

3.重启nginx

	nginx -s reload
    
4.开启服务

	gunicorn --bind 0.0.0.0:80 -w 10 "CTFd:create_app()"


此时秒进了


参考链接：
	
    https://www.cnblogs.com/qymua/p/11187624.html
	https://www.freebuf.com/sectool/155650.html
	https://www.zhaoj.in/read-6333.html
	https://blog.csdn.net/qq_17204441/article/details/93046872