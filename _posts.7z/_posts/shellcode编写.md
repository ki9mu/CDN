title: shellcode编写
abbrlink: 775955dd
date: 2019-04-19 20:22:46
tags:	二进制
categories: 技术
---
## shellcode的介绍

-  shellcode是指利用漏洞时执行的代码，目的多种多样，包括建立连接，本地提权等。
-  编写shellcode需要对目标系统的汇编语言有较深的了解。 
-  写shellcode用到的常用工具有，NASM，GDB，ObjDump， Ktrace， Strace， Readelf等。
    
## shellcode的编写的问题

#### 寻址问题
如何确定传入参数的位置？
-  通过call或者jmp来找到数据在堆栈中的位置
-  把参数压入堆栈，然后存储esp的值

例子1：
```
jmp data
code:
pop esi
ret
data:
call code
db 'KIMU'
```
这里首先跳转到data段中，然后调用call code（call是将自己下一行的地址压入堆栈，再jmp code），然后将堆栈地址放入esi中。此时esi中的内容就是字符串的地址。

例子2：
```
push 0x554d494b  //UMIK由于堆栈是反向生长的
mov esi,esp
```
例子1中代码太多了，在例子2中第二行esi就指向了字符串的位置。

## shellcode的空字节问题
在字符串的末尾会以0x00作为结束，所以我们shellcode中要绝对少的出现0x00。
对比以下代码：
```
mov eax,0
mov ax,0
mov al,0
mov al,1
xor eax,eax
```
![代码运行结果](1.jpg)
***
从这里可以看出来，对于0的赋值，只能选用xor来进行，只有xor的编码不会出现00，而对于非0的赋值，建议选择最适应的最小格式。比如小于0xff的数用al，大于0x100而小于0xffff的数用ax。

***
后面有空再更，最近有点忙。