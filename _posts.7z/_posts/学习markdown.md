title: 学习markdown
abbrlink: 6b72cdb5
tags: 其他
categories: 技术
date: 2019-03-23 16:34:03
---
## 标题
# 1级标题
##### 5级标题

```
# 1级标题
##### 5级标题
```

## 无序列表1
* 1
* 2
* 3
```
* 1
* 2
* 3
```

## 无序列表2
- 1 
- 2
- 3
```
- 1 
- 2
- 3
```
## 有序列表
2. aaaa
1. bbbb
1. cccc
5. 当有序列表的顺序不一样时会自动修改，只看第一个，然后递增

```
2. aaaa
1. bbbb
1. cccc
5. 当有序列表的顺序不一样时会自动修改，只看第一个，然后递增
```

## 引用
> 引用
`> 引用`

## 代码
`这里是单行代码块`
\`
```
这里是多行
代码块
```


## 链接
[ki9mu's blog](https://ki9mu.github.io)
`[ki9mu's blog](https://ki9mu.github.io)`

### 图片链接
![miku的图片](https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/%E5%AD%A6%E4%B9%A0markdown/miku.jpg?x-oss-process=style/ki9mu)
`![miku的图片](https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/%E5%AD%A6%E4%B9%A0markdown/miku.jpg)`

Ps:这里如果在本地浏览的话可能看不见，但上传了是能看见的。

### 本地图片链接
![鹿哥的图片](https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/%E5%AD%A6%E4%B9%A0markdown/luge.jpg?x-oss-process=style/ki9mu)
{% asset_img luge.jpg 鹿哥的图片 %}

Ps:这里有个坑，不知道为什么，插件就是装不上。
`npm install hexo-asset-image --save`
然后路径一直指向archives的图片，然后我将文章名(这里指:学习markdown)替换为8个字符(这里指6b72cdb5)。
即`![鹿哥的图片](学习markdown/luge.jpg)`
替换为`![鹿哥的图片](6b72cdb5/luge.jpg)`
但这样感觉实在有点麻烦，于是就用了后者
```
{% asset_img luge.jpg 鹿哥的图片 %}
```
而且后者能够将中括号内的字显示出来。

Ps2:这里只能用多行注释，单行注释仍为markdown的语法，然后显示图片。

## 字体
**粗体
`**粗体`


*斜体
`*斜体`

## 分割线
***
`***`


---
更新日期 2019年8月30日凌晨
## 最后说几句

这图片真的秀好吧，换了个主题，那个asset_img那个标签就凉了，整了一晚上，心累。图床是不可能图床了，这辈子都不可能图床。