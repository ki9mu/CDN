title: 'cyberpeace网站re刷题记录[初级]'
tags: ctfwp
date: 2019-10-06 23:44:30
categories: 技术
---
网站链接为：[cyberpeace网站](http://trail.cyberpeace.cn/practice_exercise/list/)
<!--more-->
![](https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%E6%AF%94%E8%B5%9B%E9%A2%98%E7%9B%AE.jpg?x-oss-process=style/ki9mu)

![upload successful](\\images\pasted-0.png\)

# 初级
***

## re1 

ida查看源码。
![ida查看源码]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dre1_ida%E6%9F%A5%E7%9C%8B%E6%BA%90%E7%A0%81.jpg?x-oss-process=style/ki9mu)

x32dbg动态调试
![动态调试]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dre1_%E5%8A%A8%E6%80%81%E8%B0%83%E8%AF%95.jpg?x-oss-process=style/ki9mu)

flag为：DUTCTF{We1c0met0DUTCTF}



## game 

打开程序，ida查找字符串

```
void sub_45F400()
{
  char v0; // [sp+Ch] [bp-F0h]@1
  int v1; // [sp+10h] [bp-ECh]@8
  int i; // [sp+DCh] [bp-20h]@6
  int v3; // [sp+F4h] [bp-8h]@2

  memset(&v0, 0xCCu, 0xF0u);
  print("                     |------------／ --------△--------|\n");
  print("                     |------------／ --------○--------|\n");
  print("                     |------------／ --------◇--------|\n");
  print("                     |------------／ --------□--------|\n");
  print("|--------------------|------------／ --------☆--------|\n");
  print("|                    |------------／ --------▽--------|\n");
  print("|                    |------------／ -----(￣▽￣)／---|\n");
  print("|                    |------------／ -----(;°Д°)----|\n");
  print("二                                                     |\n");
  print("|              by 0x61                                 |\n");
  print("|                                                      |\n");
  print("|------------------------------------------------------|\n");
  print("Play a game\nThe n is the serial number of the lamp,and m is the state of the lamp\nIf m of the Nth lamp is 1,it's on ,if not it's off\nAt first all the lights were closed\n");
  print("Now you can input n to change its state\n");
  print("But you should pay attention to one thing,if you change the state of the Nth lamp,the state of (N-1)th and (N+1)th will be changed too\n");
  print("When all lamps are on,flag will appear\n");
  print("Now,input n \n");
  while ( 1 )
  {
    while ( 1 )
    {
      print("input n,n(1-8)\n");
      sub_459418();
      print("n=");
      sub_4596D4("%d", &v3);
      print("\n");
      if ( v3 >= 0 && v3 <= 8 )
        break;
      print("sorry,n error,try again\n");
    }
    if ( v3 )
    {
      sub_4576D6(v3 - 1);
    }
    else
    {
      for ( i = 0; i < 8; ++i )
      {
        v1 = i;
        if ( (unsigned int)i >= 9 )
          sub_458919();
        byte_532E28[v1] = 0;
      }
    }
    sub_4581B7("CLS");
    sub_458054();
    if ( byte_532E28[0] == 1
      && byte_532E28[1] == 1
      && byte_532E28[2] == 1
      && byte_532E28[3] == 1
      && byte_532E28[4] == 1
      && byte_532E28[5] == 1
      && byte_532E28[6] == 1
      && byte_532E28[7] == 1 )
    {
      sub_457AB4();
    }
  }
}
```
很明显，这里的sub_457AB4()就是运行结果。跟进
```
int sub_45E940()
{
  int v0; // edx@4
  int v1; // ecx@4
  char v3; // [sp+Ch] [bp-158h]@1
  int i; // [sp+D0h] [bp-94h]@1
  char v5; // [sp+DCh] [bp-88h]@1
  char v6; // [sp+DDh] [bp-87h]@1
  char v7; // [sp+DEh] [bp-86h]@1
  char v8; // [sp+DFh] [bp-85h]@1
  char v9; // [sp+E0h] [bp-84h]@1
  char v10; // [sp+E1h] [bp-83h]@1
  char v11; // [sp+E2h] [bp-82h]@1
  char v12; // [sp+E3h] [bp-81h]@1
  char v13; // [sp+E4h] [bp-80h]@1
  char v14; // [sp+E5h] [bp-7Fh]@1
  char v15; // [sp+E6h] [bp-7Eh]@1
  char v16; // [sp+E7h] [bp-7Dh]@1
  char v17; // [sp+E8h] [bp-7Ch]@1
  char v18; // [sp+E9h] [bp-7Bh]@1
  char v19; // [sp+EAh] [bp-7Ah]@1
  char v20; // [sp+EBh] [bp-79h]@1
  char v21; // [sp+ECh] [bp-78h]@1
  char v22; // [sp+EDh] [bp-77h]@1
  char v23; // [sp+EEh] [bp-76h]@1
  char v24; // [sp+EFh] [bp-75h]@1
  char v25; // [sp+F0h] [bp-74h]@1
  char v26; // [sp+F1h] [bp-73h]@1
  char v27; // [sp+F2h] [bp-72h]@1
  char v28; // [sp+F3h] [bp-71h]@1
  char v29; // [sp+F4h] [bp-70h]@1
  char v30; // [sp+F5h] [bp-6Fh]@1
  char v31; // [sp+F6h] [bp-6Eh]@1
  char v32; // [sp+F7h] [bp-6Dh]@1
  char v33; // [sp+F8h] [bp-6Ch]@1
  char v34; // [sp+F9h] [bp-6Bh]@1
  char v35; // [sp+FAh] [bp-6Ah]@1
  char v36; // [sp+FBh] [bp-69h]@1
  char v37; // [sp+FCh] [bp-68h]@1
  char v38; // [sp+FDh] [bp-67h]@1
  char v39; // [sp+FEh] [bp-66h]@1
  char v40; // [sp+FFh] [bp-65h]@1
  char v41; // [sp+100h] [bp-64h]@1
  char v42; // [sp+101h] [bp-63h]@1
  char v43; // [sp+102h] [bp-62h]@1
  char v44; // [sp+103h] [bp-61h]@1
  char v45; // [sp+104h] [bp-60h]@1
  char v46; // [sp+105h] [bp-5Fh]@1
  char v47; // [sp+106h] [bp-5Eh]@1
  char v48; // [sp+107h] [bp-5Dh]@1
  char v49; // [sp+108h] [bp-5Ch]@1
  char v50; // [sp+109h] [bp-5Bh]@1
  char v51; // [sp+10Ah] [bp-5Ah]@1
  char v52; // [sp+10Bh] [bp-59h]@1
  char v53; // [sp+10Ch] [bp-58h]@1
  char v54; // [sp+10Dh] [bp-57h]@1
  char v55; // [sp+10Eh] [bp-56h]@1
  char v56; // [sp+10Fh] [bp-55h]@1
  char v57; // [sp+110h] [bp-54h]@1
  char v58; // [sp+111h] [bp-53h]@1
  char v59; // [sp+112h] [bp-52h]@1
  char v60; // [sp+113h] [bp-51h]@1
  char v61; // [sp+114h] [bp-50h]@1
  char v62; // [sp+120h] [bp-44h]@1
  char v63; // [sp+121h] [bp-43h]@1
  char v64; // [sp+122h] [bp-42h]@1
  char v65; // [sp+123h] [bp-41h]@1
  char v66; // [sp+124h] [bp-40h]@1
  char v67; // [sp+125h] [bp-3Fh]@1
  char v68; // [sp+126h] [bp-3Eh]@1
  char v69; // [sp+127h] [bp-3Dh]@1
  char v70; // [sp+128h] [bp-3Ch]@1
  char v71; // [sp+129h] [bp-3Bh]@1
  char v72; // [sp+12Ah] [bp-3Ah]@1
  char v73; // [sp+12Bh] [bp-39h]@1
  char v74; // [sp+12Ch] [bp-38h]@1
  char v75; // [sp+12Dh] [bp-37h]@1
  char v76; // [sp+12Eh] [bp-36h]@1
  char v77; // [sp+12Fh] [bp-35h]@1
  char v78; // [sp+130h] [bp-34h]@1
  char v79; // [sp+131h] [bp-33h]@1
  char v80; // [sp+132h] [bp-32h]@1
  char v81; // [sp+133h] [bp-31h]@1
  char v82; // [sp+134h] [bp-30h]@1
  char v83; // [sp+135h] [bp-2Fh]@1
  char v84; // [sp+136h] [bp-2Eh]@1
  char v85; // [sp+137h] [bp-2Dh]@1
  char v86; // [sp+138h] [bp-2Ch]@1
  char v87; // [sp+139h] [bp-2Bh]@1
  char v88; // [sp+13Ah] [bp-2Ah]@1
  char v89; // [sp+13Bh] [bp-29h]@1
  char v90; // [sp+13Ch] [bp-28h]@1
  char v91; // [sp+13Dh] [bp-27h]@1
  char v92; // [sp+13Eh] [bp-26h]@1
  char v93; // [sp+13Fh] [bp-25h]@1
  char v94; // [sp+140h] [bp-24h]@1
  char v95; // [sp+141h] [bp-23h]@1
  char v96; // [sp+142h] [bp-22h]@1
  char v97; // [sp+143h] [bp-21h]@1
  char v98; // [sp+144h] [bp-20h]@1
  char v99; // [sp+145h] [bp-1Fh]@1
  char v100; // [sp+146h] [bp-1Eh]@1
  char v101; // [sp+147h] [bp-1Dh]@1
  char v102; // [sp+148h] [bp-1Ch]@1
  char v103; // [sp+149h] [bp-1Bh]@1
  char v104; // [sp+14Ah] [bp-1Ah]@1
  char v105; // [sp+14Bh] [bp-19h]@1
  char v106; // [sp+14Ch] [bp-18h]@1
  char v107; // [sp+14Dh] [bp-17h]@1
  char v108; // [sp+14Eh] [bp-16h]@1
  char v109; // [sp+14Fh] [bp-15h]@1
  char v110; // [sp+150h] [bp-14h]@1
  char v111; // [sp+151h] [bp-13h]@1
  char v112; // [sp+152h] [bp-12h]@1
  char v113; // [sp+153h] [bp-11h]@1
  char v114; // [sp+154h] [bp-10h]@1
  char v115; // [sp+155h] [bp-Fh]@1
  char v116; // [sp+156h] [bp-Eh]@1
  char v117; // [sp+157h] [bp-Dh]@1
  char v118; // [sp+158h] [bp-Ch]@1
  unsigned int v119; // [sp+160h] [bp-4h]@1
  int savedregs; // [sp+164h] [bp+0h]@1

  memset(&v3, 0xCCu, 0x158u);
  v119 = (unsigned int)&savedregs ^ __security_cookie;
  print("done!!! the flag is ");
  v62 = 18;
  v63 = 64;
  v64 = 98;
  v65 = 5;
  v66 = 2;
  v67 = 4;
  v68 = 6;
  v69 = 3;
  v70 = 6;
  v71 = 48;
  v72 = 49;
  v73 = 65;
  v74 = 32;
  v75 = 12;
  v76 = 48;
  v77 = 65;
  v78 = 31;
  v79 = 78;
  v80 = 62;
  v81 = 32;
  v82 = 49;
  v83 = 32;
  v84 = 1;
  v85 = 57;
  v86 = 96;
  v87 = 3;
  v88 = 21;
  v89 = 9;
  v90 = 4;
  v91 = 62;
  v92 = 3;
  v93 = 5;
  v94 = 4;
  v95 = 1;
  v96 = 2;
  v97 = 3;
  v98 = 44;
  v99 = 65;
  v100 = 78;
  v101 = 32;
  v102 = 16;
  v103 = 97;
  v104 = 54;
  v105 = 16;
  v106 = 44;
  v107 = 52;
  v108 = 32;
  v109 = 64;
  v110 = 89;
  v111 = 45;
  v112 = 32;
  v113 = 65;
  v114 = 15;
  v115 = 34;
  v116 = 18;
  v117 = 16;
  v118 = 0;
  v5 = 123;
  v6 = 32;
  v7 = 18;
  v8 = 98;
  v9 = 119;
  v10 = 108;
  v11 = 65;
  v12 = 41;
  v13 = 124;
  v14 = 80;
  v15 = 125;
  v16 = 38;
  v17 = 124;
  v18 = 111;
  v19 = 74;
  v20 = 49;
  v21 = 83;
  v22 = 108;
  v23 = 94;
  v24 = 108;
  v25 = 84;
  v26 = 6;
  v27 = 96;
  v28 = 83;
  v29 = 44;
  v30 = 121;
  v31 = 104;
  v32 = 110;
  v33 = 32;
  v34 = 95;
  v35 = 117;
  v36 = 101;
  v37 = 99;
  v38 = 123;
  v39 = 127;
  v40 = 119;
  v41 = 96;
  v42 = 48;
  v43 = 107;
  v44 = 71;
  v45 = 92;
  v46 = 29;
  v47 = 81;
  v48 = 107;
  v49 = 90;
  v50 = 85;
  v51 = 64;
  v52 = 12;
  v53 = 43;
  v54 = 76;
  v55 = 86;
  v56 = 13;
  v57 = 114;
  v58 = 1;
  v59 = 117;
  v60 = 126;
  v61 = 0;
  for ( i = 0; i < 56; ++i )
  {
    *(&v5 + i) ^= *(&v62 + i);
    *(&v5 + i) ^= 0x13u;
  }
  print("%s\n");
  sub_459AE9(&savedregs, &dword_45EC04);
  sub_459C06();
  return sub_458801(v1, v0);
}
```
本质就是v5开始，每个数亦或V62，然后赋值给v5。最后v5开始的54个数每个亦或0x13。
脚本如下：
```
import re
string = """  v62 = 18;
  v63 = 64;
  v64 = 98;
  v65 = 5;
  v66 = 2;
  v67 = 4;
  v68 = 6;
  v69 = 3;
  v70 = 6;
  v71 = 48;
  v72 = 49;
  v73 = 65;
  v74 = 32;
  v75 = 12;
  v76 = 48;
  v77 = 65;
  v78 = 31;
  v79 = 78;
  v80 = 62;
  v81 = 32;
  v82 = 49;
  v83 = 32;
  v84 = 1;
  v85 = 57;
  v86 = 96;
  v87 = 3;
  v88 = 21;
  v89 = 9;
  v90 = 4;
  v91 = 62;
  v92 = 3;
  v93 = 5;
  v94 = 4;
  v95 = 1;
  v96 = 2;
  v97 = 3;
  v98 = 44;
  v99 = 65;
  v100 = 78;
  v101 = 32;
  v102 = 16;
  v103 = 97;
  v104 = 54;
  v105 = 16;
  v106 = 44;
  v107 = 52;
  v108 = 32;
  v109 = 64;
  v110 = 89;
  v111 = 45;
  v112 = 32;
  v113 = 65;
  v114 = 15;
  v115 = 34;
  v116 = 18;
  v117 = 16;
  v118 = 0;
"""
string2 = """
  v5 = 123;
  v6 = 32;
  v7 = 18;
  v8 = 98;
  v9 = 119;
  v10 = 108;
  v11 = 65;
  v12 = 41;
  v13 = 124;
  v14 = 80;
  v15 = 125;
  v16 = 38;
  v17 = 124;
  v18 = 111;
  v19 = 74;
  v20 = 49;
  v21 = 83;
  v22 = 108;
  v23 = 94;
  v24 = 108;
  v25 = 84;
  v26 = 6;
  v27 = 96;
  v28 = 83;
  v29 = 44;
  v30 = 121;
  v31 = 104;
  v32 = 110;
  v33 = 32;
  v34 = 95;
  v35 = 117;
  v36 = 101;
  v37 = 99;
  v38 = 123;
  v39 = 127;
  v40 = 119;
  v41 = 96;
  v42 = 48;
  v43 = 107;
  v44 = 71;
  v45 = 92;
  v46 = 29;
  v47 = 81;
  v48 = 107;
  v49 = 90;
  v50 = 85;
  v51 = 64;
  v52 = 12;
  v53 = 43;
  v54 = 76;
  v55 = 86;
  v56 = 13;
  v57 = 114;
  v58 = 1;
  v59 = 117;
  v60 = 126;
  v61 = 0;"""
l1 = re.compile("= (\\d+);").findall(string)
l2 = re.compile("= (\\d+);").findall(string2)
for i in range(0,57):
    l1[i] = int(l1[i])^int(l2[i])

for i in range(0,57):
    l1[i] = int(l1[i])^0x13

print(l1)
print("".join(chr(i) for i in l1))
```

![代码运行结果]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dgame_%E4%BB%A3%E7%A0%81%E8%BF%90%E8%A1%8C%E7%BB%93%E6%9E%9C.jpg?x-oss-process=style/ki9mu)


事实上，更简单的办法是：
 自己玩！！！
12345678直接出结果。
![玩游戏结果]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dgame_%E7%8E%A9%E6%B8%B8%E6%88%8F%E7%BB%93%E6%9E%9C.jpg?x-oss-process=style/ki9mu)



## helloctf
ida跑
![idarun.jpg]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dhelloctf_idarun.jpg?x-oss-process=style/ki9mu)
很明显的ascii码。
![ascii转换]([初级]https://ki9mu-photo.oss-cn-shanghai.aliyuncs.com/blog/article/cyberpeace%E7%BD%91%E7%AB%99re%E5%88%B7%E9%A2%98%E8%AE%B0%E5%BD%95-%E5%88%9D%E7%BA%A7/%5B%E5%88%9D%E7%BA%A7%5Dhelloctf_ascii%E8%BD%AC%E6%8D%A2.jpg?x-oss-process=style/ki9mu)
flag为CrackMeJustForFun



## open-source
直接运行
```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
	if (argc != 4) {
		printf("what?\n");
		exit(1);
	}

	unsigned int first = atoi(argv[1]);
	if (first != 0xcafe) {
		printf("you are wrong, sorry.\n");
		exit(2);
	}

	unsigned int second = atoi(argv[2]);
	if (second % 5 == 3 || second % 17 != 8) {
		printf("ha, you won't get it!\n");
		exit(3);
	}

	if (strcmp("h4cky0u", argv[3])) {
		printf("so close, dude!\n");
		exit(4);
	}

	printf("Brr wrrr grr\n");

	unsigned int hash = first * 31337 + (second % 17) * 11 + strlen(argv[3]) - 1615810207;

	printf("Get your key: ");
	printf("%x\n", hash);
	return 0;
}
```
第一个if判断参数个数应该为4(才知道运行程序原来也算一个参数)。
```C:\Users\ki9mu\Documents\Visual Studio 2015\Projects\ConsoleApplication2\Debug> .\ConsoleApplication2.exe 51966 42 h4cky0u```
第二个if判断是否为51966
atoi (表示 ascii to integer)是把字符串转换成整型数的一个函数
第三个if判断可以用很多，自己挑一个数满足余5不等于3，余17等于8。
第四个if判断比较最后一个参数和字符串h4cky0u比较。



## 
吐槽一句，国庆加班太惨了。